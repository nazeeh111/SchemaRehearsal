# Keepstep: a harmless table-rebuild comparison

Keepstep display identity; SchemaRehearsal repository, schema-rehearsal distribution/CLI and schema_rehearsal imports remain unchanged. Original MIT source and fixture terms are in LICENSE.

Contents: matching src/schema_rehearsal/ source, examples/drizzle-table-rebuild/{initial.sql,seed.sql,old.sql,fixed.sql,unchanged.sql,suite.json,run.py}, records/{old,fixed,unchanged}/{report.html,report.json}, summary.json, before.sqlite, sqlite-trace.json, LICENSE, check.py and SHA256SUMS.json. All database values are this public synthetic fixture. No application/user database is included.

No installation or runtime package dependency is needed. Use Python 3.11+ with SQLite. Tested here with CPython 3.14.7/SQLite 3.50.4, not an ORM, Cloudflare D1, better-sqlite3, migration runner or deployment. Retained generated SQL is applied directly outside an outer transaction.

Open records/old/report.html and records/fixed/report.html in a browser. Reports are script-free/self-contained. Keyboard: Enter on details, arrow keys on the focused horizontal comparison table. The JSON is the native machine artifact. Native reports omit SQL and raw result cells; summary.json and sqlite-trace.json disclose only the deliberately public synthetic fixture.

Verify saved hashes: python3 check.py --hashes-only
Freshly regenerate only this synthetic case: python check.py
Or keep a new output: python examples/drizzle-table-rebuild/run.py NEW-output-directory

The runner creates its own before.sqlite from exact initial.sql/seed.sql, independently applies each SQL in memory, and calls the actual Keepstep check CLI on fresh copies. Expected underlying CLI exits: old 1/changed/children3-to0, fixed 0/matched/3-to3, unchanged 0/matched/3-to3. Both parent IDs and the unrelated row survive; all integrity and FK checks pass. The wrapper returns 0 only when those expected results are asserted. Never use the wrapper's expected-failure assertion as an application CI gate; real check/sequence nonzero exits must fail the gate. Choose a fresh output directory with an existing parent.

The original fixture/input hashes are checked after all three comparisons. General Keepstep status codes are 0 matched, 1 changed, 2 error, 3 invalid baseline. The no-overwrite guard preserves an existing report; a failed new run can leave a partial new directory. A match covers only the declared suite; defaults deliberately change outside these observations.

The retained case follows kholdrex issue https://github.com/drizzle-team/drizzle-orm/issues/6621 (duplicate of 5469). Original generated files are retained from drizzle-kit 0.31.11/drizzle-orm 0.45.4 and 1.0.0-rc.5. This replay does not regenerate them or recommend an upgrade. Detailed provenance/optional generator lockfiles: https://github.com/nazeeh111/SchemaRehearsal/tree/1f0c4243615762a5111271b64640285a5229b9b8/examples/drizzle-table-rebuild . Matching source: https://github.com/nazeeh111/SchemaRehearsal/tree/1f0c4243615762a5111271b64640285a5229b9b8 .

SHA256SUMS.json binds every archive member except itself. These are integrity identities, not signatures, anonymization or independent timestamps. The repository figure-manifest is outside this ZIP to avoid a circular hash.
