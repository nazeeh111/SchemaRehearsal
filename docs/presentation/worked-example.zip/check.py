from pathlib import Path
import hashlib,json,sys,tempfile,subprocess,os
P=Path(__file__).resolve().parent
for n,h in json.loads((P/'SHA256SUMS.json').read_text()).items():
 assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h,n
print('All archive hashes match')
if '--hashes-only' not in sys.argv:
 with tempfile.TemporaryDirectory(prefix='keepstep-owned-fixture-')as tmp:
  out=Path(tmp)/'run';q=subprocess.run([sys.executable,'-B',str(P/'examples/drizzle-table-rebuild/run.py'),str(out)],cwd=tmp,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),text=True,capture_output=True)
  assert q.returncode==0,q.stderr+q.stdout
  for case in ['old','fixed','unchanged']:
   actual=json.loads((out/case/'report.json').read_text());expected=json.loads((P/'records'/case/'report.json').read_text())
   assert actual==expected,case
  print(q.stdout)
  print('All three native reports exactly reproduced under the tested SQLite runtime')
