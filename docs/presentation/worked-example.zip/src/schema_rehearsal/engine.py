"""Bounded SQLite copies and comparisons. This is not an OS security sandbox."""

from __future__ import annotations

import hashlib
import json
import math
import sqlite3
import time
from collections import Counter
from contextlib import ExitStack
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Limits:
    database_bytes: int = 64 * 1024 * 1024
    input_bytes: int = 1024 * 1024
    result_bytes: int = 2 * 1024 * 1024
    result_rows: int = 10_000
    seconds: float = 30


class RehearsalError(Exception):
    """A controlled diagnostic with no application values."""


def _require(condition, message):
    if not condition:
        raise RehearsalError(message)


def _keys(value, required, optional=()):
    _require(isinstance(value, dict), "Expected a JSON object.")
    _require(
        set(required) <= value.keys() and value.keys() <= set(required) | set(optional),
        "Missing or unsupported suite fields.",
    )


def _name(value):
    _require(
        isinstance(value, str)
        and 0 < len(value) <= 120
        and not any(ord(c) < 32 for c in value),
        "Names must contain 1–120 printable characters.",
    )


def _query(value, *, step, limits):
    _keys(
        value,
        ["sql"] if step else ["name", "sql"],
        ["parameters", "expect_error"] if step else ["parameters", "order"],
    )
    _require(
        isinstance(value["sql"], str)
        and 0 < len(value["sql"].encode()) <= limits.input_bytes,
        "SQL must be nonempty and within the input limit.",
    )
    params = value.get("parameters", [])
    _require(
        isinstance(params, list) and len(params) <= 100,
        "Parameters must be an array of at most 100 values.",
    )
    for p in params:
        _require(
            p is None or type(p) in (str, int, float),
            "Parameters support null, string, integer or finite real values.",
        )
        if type(p) is int:
            _require(
                -(2**63) <= p < 2**63,
                "Integer parameter is outside SQLite signed 64-bit range.",
            )
        if type(p) is float:
            _require(math.isfinite(p), "Real parameters must be finite.")
    if step and "expect_error" in value:
        _require(
            isinstance(value["expect_error"], str)
            and value["expect_error"] in CONSTRAINT_NAMES,
            "Expected errors must name an SQLite constraint code.",
        )
    if not step:
        _name(value["name"])
        _require(
            value.get("order", "ordered") in ("ordered", "multiset"),
            "Observation order must be ordered or multiset.",
        )


CONSTRAINT_NAMES = frozenset(
    name for name in dir(sqlite3) if name.startswith("SQLITE_CONSTRAINT")
)


def validate_suite(suite, limits):
    try:
        encoded = json.dumps(suite, allow_nan=False).encode()
    except (ValueError, TypeError, RecursionError):
        raise RehearsalError("Suite is not finite JSON.") from None
    _require(len(encoded) <= limits.input_bytes, "Suite exceeds the input limit.")
    _keys(suite, ["format", "scenarios"])
    _require(suite["format"] == "schema-rehearsal/v1", "Unsupported suite format.")
    cases = suite["scenarios"]
    _require(
        isinstance(cases, list) and 0 < len(cases) <= 32, "Suite needs 1–32 scenarios."
    )
    names = set()
    for case in cases:
        _keys(
            case,
            ["name", "steps", "observations"],
            ["transaction", "expect_commit_error"],
        )
        if "transaction" in case:
            _require(
                case["transaction"] == "commit", "Transaction mode must be commit."
            )
        if "expect_commit_error" in case:
            _require(
                case.get("transaction") == "commit"
                and isinstance(case["expect_commit_error"], str)
                and case["expect_commit_error"] in CONSTRAINT_NAMES,
                "Expected commit errors require commit mode and an SQLite constraint code.",
            )
        _name(case["name"])
        _require(case["name"] not in names, "Scenario names must be unique.")
        names.add(case["name"])
        _require(
            isinstance(case["steps"], list) and len(case["steps"]) <= 64,
            "A scenario permits at most 64 steps.",
        )
        _require(
            isinstance(case["observations"], list)
            and 0 < len(case["observations"]) <= 16,
            "A scenario needs 1–16 observations.",
        )
        for step in case["steps"]:
            _query(step, step=True, limits=limits)
        observed = set()
        for obs in case["observations"]:
            _query(obs, step=False, limits=limits)
            _require(
                obs["name"] not in observed,
                "Observation names must be unique within a scenario.",
            )
            observed.add(obs["name"])


def _deadline(deadline):
    if time.monotonic() >= deadline:
        raise RehearsalError("Execution time limit reached.")


def _connect(path, stack, limits):
    db = sqlite3.connect(path, isolation_level=None, timeout=0.1)
    stack.callback(db.close)
    db.execute("PRAGMA temp_store=MEMORY")
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("PRAGMA recursive_triggers=ON")
    page_size = db.execute("PRAGMA page_size").fetchone()[0]
    db.execute(f"PRAGMA max_page_count={max(1, limits.database_bytes // page_size)}")
    db.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, limits.result_bytes)
    db.setlimit(sqlite3.SQLITE_LIMIT_SQL_LENGTH, limits.input_bytes)
    db.setlimit(sqlite3.SQLITE_LIMIT_ATTACHED, 0)
    db.setlimit(sqlite3.SQLITE_LIMIT_VARIABLE_NUMBER, 100)
    return db


def _backup(source, dest, limits, deadline):
    def progress(status, remaining, total):
        _deadline(deadline)
        size = source.execute("PRAGMA page_size").fetchone()[0]
        _require(
            total * size <= limits.database_bytes, "Database exceeds the size limit."
        )

    source.backup(dest, pages=128, progress=progress, sleep=0.01)
    page_size = dest.execute("PRAGMA page_size").fetchone()[0]
    dest.execute(f"PRAGMA max_page_count={max(1, limits.database_bytes // page_size)}")


DENIED_ACTIONS = {
    sqlite3.SQLITE_ATTACH,
    sqlite3.SQLITE_DETACH,
    sqlite3.SQLITE_CREATE_VTABLE,
    sqlite3.SQLITE_DROP_VTABLE,
}
READ_PRAGMAS = {
    "table_info",
    "table_xinfo",
    "index_info",
    "index_xinfo",
    "index_list",
    "foreign_key_list",
}
MIGRATION_PRAGMAS = {"foreign_keys", "defer_foreign_keys", "user_version"}
# Functions can allocate output or introduce time/randomness outside reproducible suites.
DENIED_FUNCTIONS = {
    "load_extension",
    "readfile",
    "writefile",
    "random",
    "randomblob",
    "current_timestamp",
    "current_time",
    "current_date",
    "datetime",
    "date",
    "time",
    "julianday",
    "unixepoch",
    "strftime",
}
WRITE_ACTIONS = {
    sqlite3.SQLITE_INSERT,
    sqlite3.SQLITE_UPDATE,
    sqlite3.SQLITE_DELETE,
    sqlite3.SQLITE_CREATE_INDEX,
    sqlite3.SQLITE_CREATE_TABLE,
    sqlite3.SQLITE_CREATE_TEMP_INDEX,
    sqlite3.SQLITE_CREATE_TEMP_TABLE,
    sqlite3.SQLITE_CREATE_TEMP_TRIGGER,
    sqlite3.SQLITE_CREATE_TEMP_VIEW,
    sqlite3.SQLITE_CREATE_TRIGGER,
    sqlite3.SQLITE_CREATE_VIEW,
    sqlite3.SQLITE_DROP_INDEX,
    sqlite3.SQLITE_DROP_TABLE,
    sqlite3.SQLITE_DROP_TEMP_INDEX,
    sqlite3.SQLITE_DROP_TEMP_TABLE,
    sqlite3.SQLITE_DROP_TEMP_TRIGGER,
    sqlite3.SQLITE_DROP_TEMP_VIEW,
    sqlite3.SQLITE_DROP_TRIGGER,
    sqlite3.SQLITE_DROP_VIEW,
    sqlite3.SQLITE_ALTER_TABLE,
    sqlite3.SQLITE_REINDEX,
    sqlite3.SQLITE_ANALYZE,
}


def _guard(db, deadline, mode, allow_fts5=False):
    def authorize(action, first, second, database, trigger):
        if action in {sqlite3.SQLITE_CREATE_VTABLE, sqlite3.SQLITE_DROP_VTABLE}:
            return (
                sqlite3.SQLITE_OK
                if allow_fts5
                and mode == "migration"
                and database == "main"
                and (second or "").lower() == "fts5"
                else sqlite3.SQLITE_DENY
            )
        if action in DENIED_ACTIONS or action in {
            sqlite3.SQLITE_CREATE_TEMP_TABLE,
            sqlite3.SQLITE_CREATE_TEMP_INDEX,
            sqlite3.SQLITE_CREATE_TEMP_TRIGGER,
            sqlite3.SQLITE_CREATE_TEMP_VIEW,
        }:
            return sqlite3.SQLITE_DENY
        if (
            action == sqlite3.SQLITE_FUNCTION
            and (second or "").lower() in DENIED_FUNCTIONS
        ):
            return sqlite3.SQLITE_DENY
        if action == sqlite3.SQLITE_PRAGMA:
            name = (first or "").lower()
            # FTS5 asks for this read-only counter during MATCH and DML.
            if (
                allow_fts5
                and name == "data_version"
                and second is None
                and database == "main"
            ):
                return sqlite3.SQLITE_OK
            if name in READ_PRAGMAS:
                return sqlite3.SQLITE_OK
            if mode == "migration" and name in MIGRATION_PRAGMAS:
                return sqlite3.SQLITE_OK
            return sqlite3.SQLITE_DENY
        if mode != "migration" and action in {
            sqlite3.SQLITE_TRANSACTION,
            sqlite3.SQLITE_SAVEPOINT,
        }:
            return sqlite3.SQLITE_DENY
        if mode == "observation" and action in WRITE_ACTIONS:
            return sqlite3.SQLITE_DENY
        if mode == "step" and action in WRITE_ACTIONS - {
            sqlite3.SQLITE_INSERT,
            sqlite3.SQLITE_UPDATE,
            sqlite3.SQLITE_DELETE,
        }:
            return sqlite3.SQLITE_DENY
        return sqlite3.SQLITE_OK

    db.set_authorizer(authorize)
    db.set_progress_handler(lambda: int(time.monotonic() >= deadline), 1000)


def _unguard(db):
    db.set_authorizer(None)
    db.set_progress_handler(None, 0)


def _statements(script, deadline):
    # Skip quoted/comment semicolons before asking SQLite whether a whole
    # statement (including a trigger body) is complete. Check during scanning,
    # not only after yielding, so an adversarial input cannot starve the timer.
    start, i, state = 0, 0, "normal"
    while i < len(script):
        if i % 1024 == 0:
            _deadline(deadline)
        char = script[i]
        following = script[i + 1] if i + 1 < len(script) else ""
        if state == "line":
            if char in "\r\n":
                state = "normal"
        elif state == "block":
            if char == "*" and following == "/":
                state = "normal"
                i += 1
        elif state != "normal":
            end = "]" if state == "[" else state
            if char == end:
                if following == end and state != "[":
                    i += 1
                else:
                    state = "normal"
        elif char == "-" and following == "-":
            state = "line"
            i += 1
        elif char == "/" and following == "*":
            state = "block"
            i += 1
        elif char in ("'", '"', "`", "["):
            state = char
        elif char == ";":
            _deadline(deadline)
            if sqlite3.complete_statement(script[start : i + 1]):
                yield script[start : i + 1]
                start = i + 1
        i += 1
    _deadline(deadline)
    if script[start:].strip():
        yield script[start:]


def _cell(value):
    if value is None:
        return ("null", "")
    if isinstance(value, bytes):
        return ("blob", value.hex())
    if isinstance(value, str):
        return ("text", value)
    if isinstance(value, int):
        return ("integer", str(value))
    if isinstance(value, float):
        _require(math.isfinite(value), "Observation produced a non-finite real.")
        return ("real", value.hex())
    raise RehearsalError("Unsupported SQLite result value.")


def _rows(cursor, limits, deadline):
    rows, size = [], 0
    while True:
        _deadline(deadline)
        row = cursor.fetchone()
        if row is None:
            break
        typed = tuple(_cell(value) for value in row)
        size += len(json.dumps(typed, ensure_ascii=False).encode())
        _require(
            len(rows) < limits.result_rows and size <= limits.result_bytes,
            "Observation exceeds the result limit.",
        )
        rows.append(typed)
    return rows


def _checks(db, deadline):
    db.set_progress_handler(lambda: int(time.monotonic() >= deadline), 1000)
    try:
        integrity = db.execute("PRAGMA integrity_check(1)").fetchone() == ("ok",)
        fk_ok = db.execute("PRAGMA foreign_key_check").fetchone() is None
        return {"integrity_ok": integrity, "foreign_keys_ok": fk_ok}
    finally:
        db.set_progress_handler(None, 0)


def _schema(db):
    return {
        (kind, name): hashlib.sha256((sql or "").encode()).hexdigest()
        for kind, name, sql in db.execute(
            "SELECT type,name,sql FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%'"
        )
    }


def _fts5_tables(db, stack, limits, deadline, allow_fts5):
    # Virtual tables have no b-tree root page. Ask SQLite to parse each stored
    # declaration, capturing the actual module before denying creation. No
    # module is instantiated or extension loaded by this admission connection.
    tables = db.execute(
        "SELECT name,sql FROM main.sqlite_schema WHERE type='table' AND rootpage=0"
    ).fetchall()
    if not tables:
        return []
    _require(allow_fts5, "Virtual-table databases are unsupported.")
    admission = _connect(":memory:", stack, limits)
    for name, sql in tables:
        _deadline(deadline)
        modules = []

        def capture(action, first, second, database, trigger, modules=modules):
            if action == sqlite3.SQLITE_CREATE_VTABLE:
                modules.append(second)
            if action == sqlite3.SQLITE_INSERT and first == "sqlite_master":
                return sqlite3.SQLITE_OK
            return sqlite3.SQLITE_DENY

        admission.set_authorizer(capture)
        admission.set_progress_handler(lambda: int(time.monotonic() >= deadline), 1000)
        try:
            admission.execute(sql)
        except sqlite3.DatabaseError as error:
            _require(
                getattr(error, "sqlite_errorcode", None) == sqlite3.SQLITE_AUTH
                and len(modules) == 1
                and (modules[0] or "").lower() == "fts5",
                "Only built-in FTS5 virtual tables are supported with opt-in.",
            )
        else:
            raise RehearsalError("Virtual-table module admission failed.")
        finally:
            _unguard(admission)
    return [name for name, _ in tables]


def _initialize_fts5(db, names, deadline):
    # Connect admitted virtual tables before installing user SQL guards. Some
    # SQLite versions initialize schema metadata on first use. This fixed,
    # bounded SELECT returns no application rows and grants no user writes.
    db.set_progress_handler(lambda: int(time.monotonic() >= deadline), 1000)
    try:
        for name in names:
            _deadline(deadline)
            identifier = '"' + name.replace('"', '""') + '"'
            db.execute(f"SELECT * FROM main.{identifier} LIMIT 0").fetchall()
    finally:
        _unguard(db)


def _scenario(db, case, limits, deadline, allow_fts5=False):
    outcomes, observations = [], []
    transactional = case.get("transaction") == "commit"
    commit = None
    if transactional:
        _deadline(deadline)
        db.execute("BEGIN")
    try:
        for step in case["steps"]:
            # ROLLBACK conflict policy or a trigger may end the whole transaction.
            # Never execute the remaining application steps in autocommit mode.
            if transactional and not db.in_transaction:
                outcomes.append("not_run")
                continue
            _deadline(deadline)
            _guard(db, deadline, "step", allow_fts5)
            try:
                # Consume RETURNING/SELECT output so steps retain result bounds.
                _rows(
                    db.execute(step["sql"], step.get("parameters", [])),
                    limits,
                    deadline,
                )
                outcome = "ok"
            except sqlite3.IntegrityError as error:
                outcome = error.sqlite_errorname
            finally:
                _unguard(db)
            outcomes.append(outcome)
        if transactional:
            if not db.in_transaction:
                commit = "not_attempted"
            else:
                _deadline(deadline)
                db.set_progress_handler(lambda: int(time.monotonic() >= deadline), 1000)
                try:
                    # Only this fixed engine statement is trusted; user SQL stays guarded.
                    db.execute("COMMIT")
                    commit = "ok"
                except sqlite3.IntegrityError as error:
                    commit = error.sqlite_errorname
                finally:
                    _unguard(db)
    finally:
        # A failed COMMIT leaves SQLite in the transaction. Cleanup must not be
        # interrupted by an expired progress handler or expose pending rows.
        _unguard(db)
        if transactional and db.in_transaction:
            db.execute("ROLLBACK")
    for obs in case["observations"]:
        _guard(db, deadline, "observation", allow_fts5)
        try:
            cursor = db.execute(obs["sql"], obs.get("parameters", []))
            _require(cursor.description is not None, "Observation must return rows.")
            observations.append(
                (len(cursor.description), _rows(cursor, limits, deadline))
            )
        finally:
            _unguard(db)
    return outcomes, observations, commit


def _rehearse_many(database, migrations, suite, *, limits=None, allow_fts5=False):
    """Return a value-free report. Only explicitly selected database files are read."""
    limits = limits or Limits()
    report = {
        "format": "schema-rehearsal/report-v1",
        "sqlite_version": sqlite3.sqlite_version,
        "fts5_enabled": allow_fts5 is True,
        "status": "error",
        "exit_code": 2,
        "database_checks": {},
        "schema_changes": [],
        "scenarios": [],
    }
    reports = []
    stage = "input"
    try:
        _require(isinstance(allow_fts5, bool), "allow_fts5 must be a boolean.")
        validate_suite(suite, limits)
        for migration in migrations:
            _require(
                isinstance(migration, str)
                and 0 < len(migration.encode()) <= limits.input_bytes,
                "Migration must be nonempty and within the input limit.",
            )
        database = Path(database)
        _require(
            not database.is_symlink() and database.is_file(),
            "Database must be an existing regular file, not a symlink.",
        )
        _require(
            database.stat().st_size <= limits.database_bytes,
            "Database exceeds the size limit.",
        )
        for suffix in ("-wal", "-shm", "-journal"):
            sidecar = database.with_name(database.name + suffix)
            _require(
                not sidecar.is_symlink(), "Database sidecar symlinks are unsupported."
            )
            if sidecar.exists():
                _require(
                    sidecar.is_file()
                    and sidecar.stat().st_size <= limits.database_bytes,
                    "Database sidecar exceeds limits or is not a regular file.",
                )
        report["migration_sha256"] = hashlib.sha256(migrations[0].encode()).hexdigest()
        report["suite_sha256"] = hashlib.sha256(
            json.dumps(suite, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        deadline = time.monotonic() + limits.seconds
        with ExitStack() as stack:
            stage = "snapshot"
            source = sqlite3.connect(
                database.resolve().as_uri() + "?mode=ro",
                uri=True,
                isolation_level=None,
                timeout=0.1,
            )
            stack.callback(source.close)
            snapshot = _connect(":memory:", stack, limits)
            _backup(source, snapshot, limits, deadline)
            source.close()
            snapshot.execute("PRAGMA journal_mode=MEMORY")
            fts5_names = _fts5_tables(snapshot, stack, limits, deadline, allow_fts5)
            _initialize_fts5(snapshot, fts5_names, deadline)
            stage = "baseline"
            before_check = _checks(snapshot, deadline)
            report["database_checks"]["before"] = before_check
            if not all(before_check.values()):
                report.update(
                    status="invalid_baseline",
                    exit_code=3,
                    stage=stage,
                    diagnostic="Baseline database checks failed.",
                )
                reports.append(report)
                return reports
            report["snapshot_sha256"] = hashlib.sha256(snapshot.serialize()).hexdigest()
            before_schema = _schema(snapshot)
            migrated = _connect(":memory:", stack, limits)
            _backup(snapshot, migrated, limits, deadline)
            _initialize_fts5(migrated, fts5_names, deadline)
            common = dict(report)
            for migration in migrations:
                report = dict(
                    common,
                    database_checks={"before": before_check},
                    schema_changes=[],
                    scenarios=[],
                )
                report["migration_sha256"] = hashlib.sha256(
                    migration.encode()
                ).hexdigest()
                stage = "migration"
                _guard(migrated, deadline, "migration", allow_fts5)
                try:
                    for statement in _statements(migration, deadline):
                        _deadline(deadline)
                        _rows(migrated.execute(statement), limits, deadline)
                    _require(
                        not migrated.in_transaction,
                        "Migration left an open transaction.",
                    )
                finally:
                    _unguard(migrated)
                migrated.execute("PRAGMA foreign_keys=ON")
                migrated.execute("PRAGMA recursive_triggers=ON")
                after_check = _checks(migrated, deadline)
                report["database_checks"]["after"] = after_check
                _require(all(after_check.values()), "Migrated database checks failed.")
                after_schema = _schema(migrated)
                for key in sorted(before_schema.keys() | after_schema.keys()):
                    if before_schema.get(key) != after_schema.get(key):
                        report["schema_changes"].append(
                            {
                                "type": key[0],
                                "name": key[1],
                                "change": "added"
                                if key not in before_schema
                                else "removed"
                                if key not in after_schema
                                else "changed",
                            }
                        )
                migrated_fts5_names = [
                    row[0]
                    for row in migrated.execute(
                        "SELECT name FROM main.sqlite_schema WHERE type='table' AND rootpage=0"
                    )
                ]
                changed = False
                for case in suite["scenarios"]:
                    with ExitStack() as scenario_stack:
                        left = _connect(":memory:", scenario_stack, limits)
                        right = _connect(":memory:", scenario_stack, limits)
                        _backup(snapshot, left, limits, deadline)
                        _backup(migrated, right, limits, deadline)
                        _initialize_fts5(left, fts5_names, deadline)
                        _initialize_fts5(right, migrated_fts5_names, deadline)
                        stage = "baseline_scenario"
                        baseline_outcomes, baseline_rows, baseline_commit = _scenario(
                            left, case, limits, deadline, allow_fts5
                        )
                        expected = [
                            step.get("expect_error", "ok") for step in case["steps"]
                        ]
                        expected_commit = case.get("expect_commit_error", "ok")
                        transactional = case.get("transaction") == "commit"
                        if baseline_outcomes != expected or (
                            transactional and baseline_commit != expected_commit
                        ):
                            report.update(
                                status="invalid_baseline",
                                exit_code=3,
                                stage=stage,
                                diagnostic=(
                                    "Baseline did not meet declared step or commit outcomes."
                                    if transactional
                                    else "Baseline did not meet declared step outcomes."
                                ),
                                scenario=case["name"],
                            )
                            if transactional:
                                report["transaction"] = "commit"
                                report["commit"] = {
                                    "before": baseline_commit,
                                    "expected": expected_commit,
                                }
                                report["steps"] = [
                                    {
                                        "number": i + 1,
                                        "actual": actual,
                                        "expected": wanted,
                                    }
                                    for i, (actual, wanted) in enumerate(
                                        zip(baseline_outcomes, expected)
                                    )
                                ]
                            reports.append(report)
                            return reports
                        stage = "migrated_scenario"
                        migrated_outcomes, migrated_rows, migrated_commit = _scenario(
                            right, case, limits, deadline, allow_fts5
                        )
                        case_report = {
                            "name": case["name"],
                            "steps": [
                                {
                                    "number": i + 1,
                                    "before": a,
                                    "after": b,
                                    "equal": a == b,
                                }
                                for i, (a, b) in enumerate(
                                    zip(baseline_outcomes, migrated_outcomes)
                                )
                            ],
                            "observations": [],
                        }
                        if transactional:
                            case_report["transaction"] = "commit"
                            case_report["commit"] = {
                                "before": baseline_commit,
                                "after": migrated_commit,
                                "equal": baseline_commit == migrated_commit,
                            }
                        for obs, (cols_a, a), (cols_b, b) in zip(
                            case["observations"], baseline_rows, migrated_rows
                        ):
                            order = obs.get("order", "ordered")
                            equal = cols_a == cols_b and (
                                a == b
                                if order == "ordered"
                                else Counter(a) == Counter(b)
                            )
                            case_report["observations"].append(
                                {
                                    "name": obs["name"],
                                    "order": order,
                                    "equal": equal,
                                    "before_rows": len(a),
                                    "after_rows": len(b),
                                    "before_columns": cols_a,
                                    "after_columns": cols_b,
                                }
                            )
                        case_report["status"] = (
                            "matched"
                            if all(
                                x["equal"]
                                for x in case_report["steps"]
                                + case_report["observations"]
                                + ([case_report["commit"]] if transactional else [])
                            )
                            else "changed"
                        )
                        changed |= case_report["status"] == "changed"
                        report["scenarios"].append(case_report)
                report.update(
                    status="changed" if changed else "matched",
                    exit_code=1 if changed else 0,
                )
                reports.append(report)
            return reports
    except RehearsalError as error:
        report.update(stage=stage, diagnostic=str(error))
        if stage in ("baseline", "baseline_scenario"):
            report.update(status="invalid_baseline", exit_code=3)
    except (sqlite3.Error, OSError, UnicodeError, OverflowError) as error:
        report.update(
            stage=stage,
            diagnostic="Operation failed; raw error text is omitted to protect application values.",
            error_code=getattr(error, "sqlite_errorname", type(error).__name__),
        )
        if stage in ("baseline", "baseline_scenario"):
            report.update(status="invalid_baseline", exit_code=3)
    reports.append(report)
    return reports


def rehearse(
    database: Path,
    migration: str,
    suite: dict,
    *,
    limits: Limits | None = None,
    allow_fts5: bool = False,
):
    """Compare one migration with a frozen, read-only source snapshot."""
    return _rehearse_many(
        database, [migration], suite, limits=limits, allow_fts5=allow_fts5
    )[0]


def rehearse_sequence(
    database: Path,
    migrations: list[str],
    suite: dict,
    *,
    limits=None,
    allow_fts5: bool = False,
):
    """Compare each committed checkpoint with the same original snapshot.

    Input order is explicit. Changes do not stop later checkpoints; an execution
    error or invalid baseline does. SQL and source paths never enter the report.
    """
    limits = limits or Limits()
    result = {
        "format": "schema-rehearsal/sequence-report-v1",
        "sqlite_version": sqlite3.sqlite_version,
        "fts5_enabled": allow_fts5 is True,
        "status": "error",
        "exit_code": 2,
        "first_changed": None,
        "final_status": "not_run",
        "checkpoints": [],
    }
    try:
        _require(
            isinstance(migrations, list) and 1 <= len(migrations) <= 8,
            "A sequence needs 1–8 explicitly ordered migrations.",
        )
        _require(
            all(isinstance(sql, str) and len(sql.encode()) > 0 for sql in migrations),
            "Migrations must be nonempty SQL strings.",
        )
        _require(
            sum(len(sql.encode()) for sql in migrations) <= limits.input_bytes,
            "Combined migrations exceed the input limit.",
        )
    except RehearsalError as error:
        result.update(diagnostic=str(error), stage="input")
        return result
    reports = _rehearse_many(
        database, migrations, suite, limits=limits, allow_fts5=allow_fts5
    )
    result["sequence_sha256"] = hashlib.sha256(
        json.dumps(
            [hashlib.sha256(sql.encode()).hexdigest() for sql in migrations],
            separators=(",", ":"),
        ).encode()
    ).hexdigest()
    for number, sql in enumerate(migrations, 1):
        checkpoint = {
            "number": number,
            "migration_sha256": hashlib.sha256(sql.encode()).hexdigest(),
            "status": "not_run",
        }
        if number <= len(reports):
            report = reports[number - 1]
            checkpoint.update(status=report["status"], report=report)
            if (
                any(case["status"] == "changed" for case in report["scenarios"])
                and result["first_changed"] is None
            ):
                result["first_changed"] = number
        result["checkpoints"].append(checkpoint)
    result["snapshot_sha256"] = reports[0].get("snapshot_sha256")
    result["suite_sha256"] = reports[0].get("suite_sha256")
    result["final_status"] = result["checkpoints"][-1]["status"]
    last = reports[-1]
    status = (
        last["status"]
        if last["exit_code"] in (2, 3)
        else "changed"
        if result["first_changed"]
        else "matched"
    )
    result.update(
        status=status,
        exit_code={"matched": 0, "changed": 1, "error": 2, "invalid_baseline": 3}[
            status
        ],
    )
    return result
